﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using RTS;


    public class Manager
    {
        public int Team1Gold;
        public int Team2Gold;      
     
    }
