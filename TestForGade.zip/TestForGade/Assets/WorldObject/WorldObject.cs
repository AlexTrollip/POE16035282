﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using RTS;



public class WorldObject : MonoBehaviour {

    public string objectName;
    //PRefab saved here
    public int Health;
    protected bool currentlySelected = false;

    protected virtual void Awake()
    {

    }
    protected virtual void Start()
    {

    }
    protected virtual void Update()
    {

    }
    //Add GUI maybe
    



}
