﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using RTS;

public class Unit : WorldObject {
    protected bool unitMoving, unitRotating;

    private Vector3 unitDestination;
    private Quaternion targetRotation;
    public float moveSpeed, rotateSpeed;

    protected override void Awake()
    {
        base.Awake();
    }

    protected override void Start()
    {
        base.Start();
    }

    protected override void Update()
    {
        base.Update();
        if (unitRotating) TurnToTarget();

    }
    public void StartMove(Vector3 unitDestination)
    {
        this.unitDestination = unitDestination;
        targetRotation = Quaternion.LookRotation(unitDestination - transform.position);
    }
    private void TurnToTarget()
    {
        transform.rotation = Quaternion.RotateTowards(transform.rotation, targetRotation, rotateSpeed);
        //sometimes it gets stuck exactly 180 degrees out in the calculation and does nothing, this check fixes that
        Quaternion inverseTargetRotation = new Quaternion(-targetRotation.x, -targetRotation.y, -targetRotation.z, -targetRotation.w);
        if (transform.rotation == targetRotation || transform.rotation == inverseTargetRotation)
        {
            unitRotating = false;
            unitMoving = true;
        }
    }
    private void MakeMove()
    {
        transform.position = Vector3.MoveTowards(transform.position, unitDestination, Time.deltaTime * moveSpeed);
        if (transform.position == unitDestination) unitMoving = false;
    }


}
