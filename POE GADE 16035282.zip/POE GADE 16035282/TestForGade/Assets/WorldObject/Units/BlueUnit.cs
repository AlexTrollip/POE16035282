﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class BlueUnit : MonoBehaviour
{
    public Unit currUnit , targetUnit;
    public NavMeshAgent agent;
    public GameObject[] unitListRed;


    void Start () {
        
	}


    void Update()
    {
        currUnit = GetComponent<Unit>();
        agent = GetComponent<NavMeshAgent>();
        if (currUnit.currentState == Unit.STATE.Searching)
        {
            currUnit.ChangeState(Unit.STATE.InCombat);
            GetClosestEnemy();
            if (Vector3.Distance(currUnit.transform.position, targetUnit.transform.position) > currUnit.attackRange)
            {
                agent.SetDestination(targetUnit.transform.position);
                agent.Resume();
            }

            else
            {
                agent.Stop();
            }
        }
    }




    public void GetClosestEnemy()
    {
        unitListRed = GameObject.FindGameObjectsWithTag("red");
        Transform tMin = null;
        float minDist = Mathf.Infinity;
        Vector3 currentPos = gameObject.transform.position;

        foreach (GameObject t in unitListRed)
        {
            float dist = Vector3.Distance(t.transform.position, currentPos);
            if (dist < minDist)
            {
                tMin = t.transform;
                minDist = dist;
                targetUnit = t.GetComponent<Unit>();
            }
        }
    }

}
