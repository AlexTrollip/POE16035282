﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class RedUnit : MonoBehaviour {

    public Unit currUnit, targetUnit;
    public NavMeshAgent agent;
    
    public GameObject[] unitListBlue;


    void Start()
    {
        
    }


    void Update()
    {
        currUnit = GetComponent<Unit>();
        agent = GetComponent<NavMeshAgent>();
        //if (currUnit.currentState == Unit.STATE.Searching)
        //{
        currUnit.ChangeState(Unit.STATE.InCombat);
            targetUnit = GetClosestEnemy();
            if (Vector3.Distance(currUnit.transform.position, targetUnit.transform.position) > currUnit.attackRange)
            {
                agent.SetDestination(targetUnit.transform.position);
                agent.Resume();
            }

            else
            {
                agent.Stop();
            }
        //}
    }

    public Unit GetClosestEnemy()
    {
        unitListBlue = GameObject.FindGameObjectsWithTag("blue");
        Transform tMin = null;
        float minDist = Mathf.Infinity;
        Vector3 currentPos = gameObject.transform.position;
        foreach (GameObject t in unitListBlue)
        {
            float dist = Vector3.Distance(t.transform.position, currentPos);
            if (dist < minDist)
            {
                tMin = t.transform;
                minDist = dist;
                targetUnit = t.GetComponent<Unit>();
            }
        }
        return targetUnit;
    }
   

}
