﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Unit : MonoBehaviour {

    public enum STATE { InCombat, Searching, Fleeing };

    [Header("State")]
    public STATE currentState;
    public TextMesh myStateText;

    [Header("Stats")]
    public int health = 100;
    public int damage = 10;
    public float speed = 10f;
    public float attackRange = 1f;
    public string type = "Unit"; //Need to get that from Melee or ranged.

    private void Start()
    {
        myStateText = GetComponentInChildren<TextMesh>();

        ChangeState(STATE.Searching);
    }
    public void ChangeState(STATE state)
    {
        currentState = state;
        if(myStateText != null)
        {
            myStateText.text = state.ToString();
        }
    }

    protected void Update()
    {

    }
    


}
