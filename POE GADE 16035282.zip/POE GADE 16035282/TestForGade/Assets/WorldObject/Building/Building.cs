﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Building : MonoBehaviour {

    private int health = 100;
    public string type = "Building";


    private void Start()
    {
        
    }


}
