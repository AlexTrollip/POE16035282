﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour {
    [SerializeField] private float travelPan = 20f;
    [SerializeField] private float travelHeight = 5f;
    [SerializeField] private float rotatePan = 2f;
    [SerializeField] private float rotateHeight = 2f;

    [SerializeField] private float xWorldBorder = 50f;
    [SerializeField] private float yWorldBorderTop = 20f;
    [SerializeField] private float yWorldBorderBottom = 2f;
    [SerializeField] private float zWorldBorder = 50f;
    Vector3 cameraStartPosition;
    private Quaternion cameraStartRotation;
    // Use this for initialization
    void Start () {
        cameraStartPosition = transform.position;
        cameraStartRotation = transform.rotation;
	}
	
	// Update is called once per frame
	void Update () {
        //For entering keys to move camera, checks for key press then checks if camera is still within the border of the game.
        if (Input.GetKey(KeyCode.W) && gameObject.transform.position.z < zWorldBorder)
        {
            gameObject.transform.Translate(0, 0,  travelPan * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.S) && gameObject.transform.position.z > -zWorldBorder)
        {
            gameObject.transform.Translate(0, 0, -travelPan * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.A) && gameObject.transform.position.x > -xWorldBorder)
        {
            gameObject.transform.Translate(-travelPan * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.D) && gameObject.transform.position.x < xWorldBorder)
        {
            gameObject.transform.Translate( travelPan * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.Space) && gameObject.transform.position.y < yWorldBorderTop)
        {
            gameObject.transform.Translate(0,  travelHeight * Time.deltaTime, 0);
        }
        if (Input.GetKey(KeyCode.C) && gameObject.transform.position.y > yWorldBorderBottom)
        {
            gameObject.transform.Translate(0, -travelHeight * Time.deltaTime, 0);
        }
        //Rotation of Camera, remember to add key to game somehow to show user how to use this.
        if (Input.GetKey(KeyCode.E))
        {
            gameObject.transform.Rotate(0, rotatePan, 0);
        }
        if(Input.GetKey(KeyCode.Q))
        {
            gameObject.transform.Rotate(0, - rotatePan, 0);
        }
        if (Input.GetKey(KeyCode.LeftControl))
        {
            gameObject.transform.Rotate(-rotateHeight, 0, 0);
        }
        if (Input.GetKey(KeyCode.LeftAlt))
        {
            gameObject.transform.Rotate( rotateHeight, 0, 0);
        }
        //This really messes up in game so for user friendlyness I am going to add a base key.
        if (Input.GetKey(KeyCode.Backspace))
        {
            gameObject.transform.position = cameraStartPosition;
            gameObject.transform.rotation = cameraStartRotation;

        }
    }
}
