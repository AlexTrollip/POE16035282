﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HPBar : MonoBehaviour {

    public float distY;
    public float distZ;

    public Transform user;

    private void Update()
    {
        transform.eulerAngles = Camera.main.transform.eulerAngles;
        if (user != null)
        {
            Vector3 pos = new Vector3(user.position.x, user.position.y+distY, user.position.z +distZ)
            transform.position = pos;
        }
    }
}
