﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Floating_Text : MonoBehaviour {

    public string stuff;
    public TextMesh userTextMesh;

    private void Start()
    {
        userTextMesh.text = stuff;
        userTextMesh.transform.eulerAngles = Camera.main.transform.eulerAngles;

    }
}
