﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeStrategyTest
{
    class Map
    {
        private string[,] mapMap = new string[20, 20];
        private List<Unit> team1List = new List<Unit>();
        private List<Unit> team2List = new List<Unit>();
        ResourceBuilding team1RB = new ResourceBuilding(0, 0, 9000, "Team1", "B");
        ResourceBuilding team2RB = new ResourceBuilding(19, 0, 9000, "Team2", "b");
        FactoryBuilding team1FB = new FactoryBuilding(0, 19, 10000, "Team1", "F");
        FactoryBuilding team2FB = new FactoryBuilding(19, 19, 10000, "Team2", "f");


        private const string Blank = ".";
        bool RangedOrMelee;

        public ResourceBuilding Team1RB
        {
            get { return team1RB; }
        }
        public ResourceBuilding Team2RB
        {
            get { return team2RB; }
        }
        public FactoryBuilding Team1FB
        {
            get { return team1FB; }
        }
        public FactoryBuilding Team2FB
        {
            get { return team2FB; }
        }

        public List<Unit> Team1
        {
            get { return team1List; }
            set { value = team1List; }
        }
        public List<Unit> Team2
        {
            get { return team2List; }
            set { value = team2List; }
        }

        public string[,] MapMap
        {
            get
            {
                return mapMap;
            }
        }
        public void RandomGenerator()
        {
            
            //This creates a 20x20 array of just .
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    mapMap[i, j] = Blank;
                }
            }
            //Okay make sure factions go from random points above and then below 10;
            //************************************************
            //Make Buildings and add them to set positions
            Random rnd = new Random();
            int x, y;
            int team1, team2;

            x = team1RB.XPos; 
            y = team1RB.YPos;

            mapMap[x,y] = team1RB.Image;

            x = team2RB.XPos;
            y = team2RB.YPos;

            mapMap[x, y] = team2RB.Image;

            x = team1FB.XPos;
            y = team1FB.YPos;

            mapMap[x, y] = team1FB.Image;

            x = team2FB.XPos;
            y = team2FB.YPos;

            mapMap[x, y] = team2FB.Image;
            


            //This will randomly populate positions for units in different factions.


            team1 = rnd.Next(1, 5);
            team2 = rnd.Next(1, 5);
            x = rnd.Next(0, 20);
            y = rnd.Next(0, 20);
            for (int i = 0; i < team1; i++)
            {
                if (mapMap[x, y] == Blank)
                {


                    RangedOrMelee = rnd.Next(0, 3) % 2 == 1;
                    if (RangedOrMelee)
                    {
                        Unit tmp = new MeleeUnit("Barbarian",x, y, 100, 1, 10, 1, "Team1", "M", false, true);
                        team1List.Add(tmp);
                        mapMap[x, y] = tmp.Image;
                    }
                    else
                    {
                        Unit tmp = new RangedUnit("Archer", x, y, 50, 1, 5, 2, "Team1", "R", false, true);
                        team1List.Add(tmp);
                        mapMap[x, y] = tmp.Image;
                    }
                    x = rnd.Next(0, 10);
                    y = rnd.Next(0, 10);
                }
                else
                {
                    i--;
                }
            }

            x = rnd.Next(10, 19);
            y = rnd.Next(10, 19);
            for (int i = 0; i < team2; i++)
            {
                if (mapMap[x, y] == Blank)
                {


                    RangedOrMelee = rnd.Next(0, 3) % 2 == 1;
                    if (RangedOrMelee)
                    {
                        Unit tmp = new MeleeUnit("Legionnaire",x, y, 100, 1, 10, 1, "Team2", "m", false, true);
                        team2List.Add(tmp);
                        mapMap[x, y] = tmp.Image;
                    }
                    else
                    {
                        Unit tmp = new RangedUnit("Auxillary", x, y, 50, 1, 5, 2, "Team2", "r", false, true);
                        team2List.Add(tmp);
                        mapMap[x, y] = tmp.Image;
                    }
                    x = rnd.Next(10, 19);
                    y = rnd.Next(10, 19);
                }
                else
                {
                    i--;
                }
            }
        }

        public void MoveUnit(Unit u, int newX, int newY)
        {
            mapMap[u.XPos, u.YPos] = Blank;
            mapMap[newX, newY] = u.Image;
        }
        public void UpdatePosition(Unit u, int newX, int newY)
        {
            //should check for these parameters before I call this method perhaps or create a method that checks for if unit is there or if it is going out of bounds.
            if((newX >= 0 && newX < 20) && (newY >= 0 && newY < 20))
            MoveUnit(u, newX, newY);
            u.Position(newX, newY);
        }
        public void checkHealth()
        {
            for (int i = 0; i < team1List.Count; i++)
            {
                if (!team1List[i].Death())
                {
                    MapMap[team1List[i].XPos, team1List[i].YPos] = Blank;
                    team1List.RemoveAt(i);
                    
                }
            }
            for (int i = 0; i < team2List.Count; i++)
            {
                if (!team1List[i].Death())
                {
                    MapMap[team2List[i].XPos, team2List[i].YPos] = Blank;
                    team2List.RemoveAt(i);

                }
            }
        }

        public void NewMapFromLoad()
        {
            // Clear map
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    mapMap[i, j] = Blank;
                }
            }
            //Add buildings
            int x, y;

            x = team1RB.XPos;
            y = team1RB.YPos;

            mapMap[x, y] = team1RB.Image;

            x = team2RB.XPos;
            y = team2RB.YPos;

            mapMap[x, y] = team2RB.Image;

            x = team1FB.XPos;
            y = team1FB.YPos;

            mapMap[x, y] = team1FB.Image;

            x = team2FB.XPos;
            y = team2FB.YPos;

            mapMap[x, y] = team2FB.Image;

            foreach (Unit u in team1List)
            {
                x = u.XPos;
                y = u.YPos;

                mapMap[x, y] = u.Image;
            }
            foreach (Unit u in team2List)
            {
                x = u.XPos;
                y = u.YPos;

                mapMap[x, y] = u.Image;
            }
        }

    }
       
}

