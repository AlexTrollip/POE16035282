﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeStrategyTest
{
    abstract class Building
    {
        protected int Xpos;
        protected int Ypos;
        protected int health;
        protected string team;
        protected string image;

        public int XPos
        {
            get { return Xpos; }
            set { Xpos = value; }
        }

        public int YPos
        {
            get { return Ypos; }
            set { Ypos = value; }
        }
        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        public string Team
        {
            get { return team; }
            set { team = value; }

        }

        public string Image
        {
            get { return image; }
            set { image = value; }
        }

        //Constructor
        public Building (int Xpos, int Ypos, int health, string team, string image)
        {
            this.Xpos = Xpos;
            this.Ypos = Ypos;
            this.health = health;
            this.team = team;
            this.image = image;

        }
        ~Building()
        {

        }
        //AlternateMethods
        public abstract bool Death();

        public abstract string toString();
    


    }
}
