﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RealTimeStrategyTest
{
    public partial class Form1 : Form
    {
        int Seconds;
        GameEngine game = new GameEngine();
        public Form1()
        {
            InitializeComponent();
        }
        private void lblMap_Click(object sender,EventArgs e)
        {
            int mouseX = MousePosition.X;
            int mouseY = MousePosition.Y;

            int formX = this.Location.X;
            int formY = this.Location.Y;

            int x = (mouseY - formY - 70 - 1) / 15;
            int y = (mouseX - formX - 39 - 6) / 15;

            // The values need to be edited to be better suited to the size of my label. Time however doesnt give me time for that.

            txtUnitInfo.Text = "";

            foreach (Unit u in game.map.Team1)
            {
                if (u.XPos == x && u.YPos == y)
                    txtUnitInfo.Text += u.ConvertToString();
            }
            foreach (Unit u in game.map.Team2)
            {
                if (u.XPos == x && u.YPos == y)
                    txtUnitInfo.Text += u.ConvertToString();
            }
            //Check for building values for click to give info






        }
        private void btnStart_Click(object sender, EventArgs e)
        {
            GameTimer.Enabled = true;
            GameTimer.Start();
            btnPause.Enabled = true;
            btnStart.Enabled = false;


        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            GameTimer.Stop();
            btnPause.Enabled = false;
            btnStart.Enabled = true;
        }

        private void printToForm()
        {
            txtMap.Text = "";
            for (int x = 0; x < 20; x++)
            {
                for (int y = 0; y < 20; y++)
                {
                    txtMap.Text += (game.map.MapMap[x, y]+"   ");
                }
                txtMap.Text += (Environment.NewLine);
            }
        }
        private void GameTimer_Tick(object sender, EventArgs e)
        {        
            Seconds++;
            lblTimer.Text = ("Time : " + Convert.ToString(Seconds));
            game.start();
            printToForm();


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            game.Save();
            MessageBox.Show("Game values have been saved");

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            //Load does have a problem of null finding stuff.
            game.Load();
            game.map.NewMapFromLoad();
            printToForm();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
        }
    }
}
