﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeStrategyTest
{
    class MeleeUnit : Unit
    {
        public MeleeUnit(string name,int Xpos, int Ypos, int health, int speed, int attack, int attack_range, string team, string image, bool combatStatus, bool alive )
                          : base(name, Xpos, Ypos, health, speed, attack, attack_range, team, image, combatStatus, alive)
        {
            //attack = 10;
            //health = 100;
            //attack_range = 1;
        }
        public override void Position(int x, int y)
        {
            if (x >= 0 && x < 20)
                Xpos = x;
            if (y >= 0 && y < 20)
                Ypos = y;

        }
        public override void Combat(Unit enemy)
        {
            if (AttackRange(enemy))
            {
                enemy.Health -= attack;
            }

        }
        public override bool AttackRange(Unit enemy)
        {
            if ((Math.Abs(this.XPos - enemy.XPos) <= this.Attack_range) || ((Math.Abs(this.YPos - enemy.XPos)) <= this.Attack_range))
                {
                return true;
                }
            else
                return false;

        }
        public override Unit ClosestUnit(List<Unit> List)
        {
            Unit Closest = null;

            int rangeX,rangeY, rangeB;
            int shortestRange = 1000;

            foreach (Unit u in List)
            {
                rangeX = Math.Abs(this.Xpos - u.XPos);
                rangeY = Math.Abs(this.Xpos - u.XPos);
                //Check for biggest difference in X and Y and make that the distance as this makes it more accurate to find the closest actual unit, especially if diagonals are counted as same as straight moves.
                if (rangeX >= rangeY)
                    rangeB = rangeX;
                else
                    rangeB = rangeY;
                //This following does not check for the if two units are equally close because it doenst really matter.
                if (rangeB< shortestRange)
                {
                    shortestRange = rangeB;
                    Closest = u;
                }
            }

            return Closest;
        }
        public override bool Death()
        {
            if (this.health <= 0)
                return false;
            else
                return true;
            
        }
        public override string ConvertToString()
        {
            string Info = ("There is an issue of X and Y being swapped" + Environment.NewLine +
                             "X Co-ordinate   =" + Xpos + Environment.NewLine +
                             "Y Co-ordinate =" + Ypos + Environment.NewLine +
                             "Health        =" + health + Environment.NewLine +
                             "Speed         =" + speed + Environment.NewLine +
                             "Attack        =" + attack + Environment.NewLine +
                             "Attack Range  =" + attack_range + Environment.NewLine +
                             "Team          =" + team + Environment.NewLine +
                             "Image         =" + image + Environment.NewLine);
           return Info;
        }
    }
}
