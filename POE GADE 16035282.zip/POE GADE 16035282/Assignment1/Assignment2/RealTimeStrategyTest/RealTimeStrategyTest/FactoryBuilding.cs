﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeStrategyTest
{
    class FactoryBuilding : Building
    {
        protected int numberOfUnits = 0;
        protected int unitBuildTime = 5;
        protected int spawnX, spawnY;

        public FactoryBuilding( int Xpos, int Ypos, int health, string team, string image)
                    : base ( Xpos,  Ypos,  health,  team,  image)
        {
             
        }

            public static void NewUnit()
        {
            

        }
            public override bool Death()
        {
            if (this.health <= 0)
                return false;
            else
                return true;
        }
            public override string toString()
        {
            string Info = ( "X Co-ordinate =" + Xpos + Environment.NewLine +
                            "Y Co-ordinate =" + Ypos + Environment.NewLine +
                            "Health        =" + health + Environment.NewLine +
                            "Team          =" + team + Environment.NewLine +
                            "Image         =" + image + Environment.NewLine);
            return Info;
        }

    }
}
