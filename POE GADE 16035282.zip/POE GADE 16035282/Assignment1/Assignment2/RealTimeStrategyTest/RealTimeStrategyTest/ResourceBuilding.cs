﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeStrategyTest
{
    class ResourceBuilding :Building
    {
        //Resource Type, Resource per tick, Resources total.
        //Adding default values though these can be changed.
        protected const string resourceType = "Bits";
        protected const int resourceFrequency = 5;
        protected int resourceQuantity = 0;
        protected const int unitCost = 50;

       public ResourceBuilding ( int Xpos, int Ypos, int health, string team, string image)
                    : base ( Xpos,  Ypos,  health,  team,  image)
        {
             
        }
        public int ResourceAdjust()
        {
            resourceQuantity += resourceFrequency;
            return resourceQuantity;
        }
        public int BuiltUnit()
        {
            resourceQuantity -= unitCost;
            return resourceQuantity;
        }
         public override bool Death()
        {
            if (this.health <= 0)
                return false;
            else
                return true;
        }
        public override string toString()
        {
            string Info = ( "X Co-ordinate =" + Xpos + Environment.NewLine +
                            "Y Co-ordinate =" + Ypos + Environment.NewLine +
                            "Health        =" + health + Environment.NewLine +
                            "Team          =" + team + Environment.NewLine +
                            "Image         =" + image + Environment.NewLine);
            return Info;
        }
    }
}
