﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeStrategyTest
{
    abstract class Unit

    {
        protected int Xpos;
        protected int Ypos;
        protected int health;
        protected int speed;
        protected int attack;
        protected int attack_range;
        protected string team;
        protected string image;
        protected bool combatStatus;
        protected bool alive;
        protected string name;
        //Accesors will be shortened to {get; set;} so i can more easily use seperate Lists for ranged and melee for each team. This however is difficult with the naming of variables ive done this far
        //Need to change this for the POE
        public int XPos
        {
            get { return Xpos; }
            set { Xpos = value; }
        }
        public int YPos
        {
            get { return Ypos; }
            set { Ypos = value; }
        }
        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }
        public int Attack
        {
            get { return attack; }
            set { attack = value; }
        }
        public int Attack_range
        {
            get { return attack_range; }
            set { attack_range = value; }
        }
        public string Team
        {
            get { return team; }
            set { team = value; }
        }
        public string Image
        {
            get { return image; }
            set { image = value; }
        }
        public bool CombatStatus
        {
            get { return combatStatus; }
            set { combatStatus = value; }
        }
        public bool Alive
        {
            get { return alive; }
            set { alive = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }


        //got to change the constructor to have all the values in
        //using this. variable to assign them in the default.
        // add a destructor
        public Unit(string name, int Xpos, int Ypos, int health, int speed, int attack, int attack_range, string team, string image, bool combatStatus, bool alive)
        {
            this.name = name;
            this.Xpos = Xpos;
            this.Ypos = Ypos;
            this.health = health;
            this.speed = speed = 1;
            this.attack = attack;
            this.attack_range = attack_range;
            this.team = team;
            this.image = image;
            this.combatStatus = combatStatus;
            this.alive = alive;
            
        }
        ~Unit()
        {

        }
        //add the parameters for these abstract methods.
        public abstract void Position(int x, int y);

        public abstract void Combat(Unit Enemy);

        public abstract bool AttackRange(Unit Enemy);

        public abstract Unit ClosestUnit(List<Unit> list);

        public abstract bool Death();

        public abstract string ConvertToString();
        

        


        
    }
}
