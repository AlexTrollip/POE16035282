﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace RealTimeStrategyTest
{
    class GameEngine
    {
        //Possibly add checks for not having units move to a place already occupied before sending to map.
        public Map map = new Map();

        public GameEngine()
        {
            map.RandomGenerator();
        }
        public void Load()
        {
            string line;

            map.Team1.Clear();
            map.Team2.Clear();

            

            FileStream load1 = new FileStream("SaveGames\\Team1Info.txt", FileMode.Open, FileAccess.Read);
            StreamReader reader1 = new StreamReader(load1);

            map.Team1RB.XPos = int.Parse(reader1.ReadLine());
            map.Team1RB.YPos = int.Parse(reader1.ReadLine());
            map.Team1RB.Health = int.Parse(reader1.ReadLine());
            map.Team1RB.Team = reader1.ReadLine();
            map.Team1RB.Image = reader1.ReadLine();
            map.Team1FB.XPos = int.Parse(reader1.ReadLine());
            map.Team1FB.YPos = int.Parse(reader1.ReadLine());
            map.Team1FB.Health = int.Parse(reader1.ReadLine());
            map.Team1FB.Team = reader1.ReadLine();
            map.Team1FB.Image = reader1.ReadLine();

            //Units need to go here with a read till the end of the textfile and then also loop to add to units to list

            //Check if line is empty, priming read
            line = reader1.ReadLine();
            while (line != null)
            {
                //If line isnt empty there are units, meaning there are 11 fields to get
                //Check if melee or ranged, can use a to char array to check first letter of name if there are more than two types of unit and then use a switch to get right method.
                if (line == "Barbarian")
                {
                    Unit tmp = new MeleeUnit(line, int.Parse(reader1.ReadLine()), int.Parse(reader1.ReadLine()), int.Parse(reader1.ReadLine()), 
                        int.Parse(reader1.ReadLine()), int.Parse(reader1.ReadLine()), int.Parse(reader1.ReadLine()), 
                        reader1.ReadLine(), reader1.ReadLine(), Convert.ToBoolean(reader1.ReadLine()), Convert.ToBoolean(reader1.ReadLine()));
                    map.Team1.Add(tmp);
                }
                else if (line == "Archer")
                {
                    Unit tmp = new RangedUnit(line, int.Parse(reader1.ReadLine()), int.Parse(reader1.ReadLine()), int.Parse(reader1.ReadLine()), int.Parse(reader1.ReadLine()), int.Parse(reader1.ReadLine()), int.Parse(reader1.ReadLine()), reader1.ReadLine(), reader1.ReadLine(), Convert.ToBoolean(reader1.ReadLine()), Convert.ToBoolean(reader1.ReadLine()));
                    map.Team1.Add(tmp);
                }
                line = reader1.ReadLine()  ;  
            }
            reader1.Close();
            load1.Close();

            FileStream load2 = new FileStream("SaveGames\\Team2Info.txt", FileMode.Open, FileAccess.Read);
            StreamReader reader2 = new StreamReader(load2);

            map.Team2RB.XPos = int.Parse(reader2.ReadLine());
            map.Team2RB.YPos = int.Parse(reader2.ReadLine());
            map.Team2RB.Health = int.Parse(reader2.ReadLine());
            map.Team2RB.Team = reader2.ReadLine();
            map.Team2RB.Image = reader2.ReadLine();
            map.Team2FB.XPos = int.Parse(reader2.ReadLine());
            map.Team2FB.YPos = int.Parse(reader2.ReadLine());
            map.Team2FB.Health = int.Parse(reader2.ReadLine());
            map.Team2FB.Team = reader2.ReadLine();
            map.Team2FB.Image = reader2.ReadLine();

            //Units need to go here with a read till the end of the textfile and then also loop to add to units to list

            //Check if line is empty, priming read
            line = reader2.ReadLine();
                   
            while (line != null)
            {
                //If line isnt empty there are units, meaning there are 11 fields to get
                //Check if melee or ranged, can use a to char array to check first letter of name if there are more than two types of unit and then use a switch to get right method.
                if (line == "Legionnaire")
                {
                    Unit tmp = new MeleeUnit(line, int.Parse(reader2.ReadLine()), int.Parse(reader2.ReadLine()), int.Parse(reader2.ReadLine()), int.Parse(reader2.ReadLine()), int.Parse(reader2.ReadLine()), int.Parse(reader2.ReadLine()), reader2.ReadLine(), reader2.ReadLine(), Convert.ToBoolean(reader2.ReadLine()), Convert.ToBoolean(reader2.ReadLine()) );
                    map.Team2.Add(tmp);
                }
                else if (line == "Auxilliary")
                {
                    Unit tmp = new RangedUnit(line, int.Parse(reader2.ReadLine()), int.Parse(reader2.ReadLine()), int.Parse(reader2.ReadLine()), int.Parse(reader2.ReadLine()), int.Parse(reader2.ReadLine()), int.Parse(reader2.ReadLine()), reader2.ReadLine(), reader2.ReadLine(), Convert.ToBoolean(reader2.ReadLine()), Convert.ToBoolean(reader2.ReadLine()) );
                    map.Team2.Add(tmp);
                }
                line = reader2.ReadLine();        
            }
            reader2.Close();
            load2.Close();




        }
        public void Save()
        {
            //I dont agree with how the assingment decides to save the stuff to textfile, i chose this method as it allows me to have seperate files for factions.
            //I could change this to be in the unit and building classes but this seems more succint and easy to see.
            FileStream saveT1 = new FileStream("SaveGames\\Team1Info.txt", FileMode.Create, FileAccess.Write);
            StreamWriter writer1 = new StreamWriter(saveT1);

            writer1.WriteLine(map.Team1RB.XPos);
            writer1.WriteLine(map.Team1RB.YPos);
            writer1.WriteLine(map.Team1RB.Health);
            writer1.WriteLine(map.Team1RB.Team);
            writer1.WriteLine(map.Team1RB.Image);
            writer1.WriteLine(map.Team1FB.XPos);
            writer1.WriteLine(map.Team1FB.YPos);
            writer1.WriteLine(map.Team1FB.Health);
            writer1.WriteLine(map.Team1FB.Team);
            writer1.WriteLine(map.Team1FB.Image);

            foreach (Unit u in map.Team1)
            {
                writer1.WriteLine(u.Name);
                writer1.WriteLine(u.XPos);
                writer1.WriteLine(u.YPos);
                writer1.WriteLine(u.Health);
                writer1.WriteLine(u.Speed);
                writer1.WriteLine(u.Attack);
                writer1.WriteLine(u.Attack_range);
                writer1.WriteLine(u.Team);
                writer1.WriteLine(u.Image);
                writer1.WriteLine(u.CombatStatus);
                writer1.WriteLine(u.Alive);
                             
            }
            writer1.Close();
            saveT1.Close();
            FileStream saveT2 = new FileStream ("SaveGames\\Team2Info.txt", FileMode.Create, FileAccess.Write);
            StreamWriter writer2 = new StreamWriter(saveT2);
            writer2.WriteLine(map.Team2RB.XPos);
            writer2.WriteLine(map.Team2RB.YPos);
            writer2.WriteLine(map.Team2RB.Health);
            writer2.WriteLine(map.Team2RB.Team);
            writer2.WriteLine(map.Team2RB.Image);
            writer2.WriteLine(map.Team2FB.XPos);
            writer2.WriteLine(map.Team2FB.YPos);
            writer2.WriteLine(map.Team2FB.Health);
            writer2.WriteLine(map.Team2FB.Team);
            writer2.WriteLine(map.Team2FB.Image);
            foreach (Unit u in map.Team2)
            {
                writer2.WriteLine(u.Name);
                writer2.WriteLine(u.XPos);
                writer2.WriteLine(u.YPos);
                writer2.WriteLine(u.Health);
                writer2.WriteLine(u.Speed);
                writer2.WriteLine(u.Attack);
                writer2.WriteLine(u.Attack_range);
                writer2.WriteLine(u.Team);
                writer2.WriteLine(u.Image);
                writer2.WriteLine(u.CombatStatus);
                writer2.WriteLine(u.Alive);
                
            }
            writer2.Close();
            saveT2.Close();

        }
        public void start()
        {
            int newX, newY;
            Unit closest;
            //Chess rules, team 1 moves then team 2

            for (int j = 0; j < map.Team1.Count; j++)
            {
                if (!map.Team1[j].CombatStatus)
                    {
                        closest = map.Team1[j].ClosestUnit(map.Team2);

                        if (map.Team1[j].XPos < closest.XPos)
                            newX = map.Team1[j].XPos + map.Team1[j].Speed;
                        else if (map.Team1[j].YPos < closest.YPos)
                            newX = map.Team1[j].XPos - map.Team1[j].Speed;
                        else
                            newX = map.Team1[j].XPos;

                        if (map.Team1[j].YPos < closest.YPos)
                            newY = map.Team1[j].YPos + map.Team1[j].Speed;
                        else if (map.Team1[j].YPos < closest.YPos)
                            newY = map.Team1[j].YPos - map.Team1[j].Speed;
                        else
                            newY = map.Team1[j].YPos;

                        map.UpdatePosition(map.Team1[j], newX, newY);
                    }
                //Movement if not in combat done
                if (map.Team1[j].CombatStatus)
                {
                    for (int i = 0; i < map.Team2.Count; i++)
                    {
                        //this causes the unit in combat to attack every unit in range, not sure if thats balanced but it works so its fine. (works in game For Honour for quantity balancing so why not)
                        map.Team1[j].Combat(map.Team2[i]);
                    }
                }
                //Checking if unit is not in combat now, if in range currently make in combat.
                if(!map.Team1[j].CombatStatus)
                {
                    for (int i = 0; i < map.Team2.Count; i++)
                    {
                       if( map.Team1[j].AttackRange(map.Team2[i]))
                            map.Team1[j].CombatStatus = true;
                    }
                    
                }
                //Checking for health below 25 now, i should maybe add this to only be in combat once someone gets damaged but this works here as well
                if (map.Team1[j].Health < 25)
                {
                    closest = map.Team1[j].ClosestUnit(map.Team2);
                    //If below move directly away from unit closest. This can be advanced to have multiple checks to move in a direction furthest away from units total though that seems excessive.
                    if (map.Team1[j].XPos < closest.XPos)
                        newX = map.Team1[j].XPos - map.Team1[j].Speed;
                    else if (map.Team1[j].XPos > closest.XPos)
                        newX = map.Team1[j].XPos + map.Team1[j].Speed;
                    else
                        newX = map.Team1[j].XPos;

                    if (map.Team1[j].YPos < closest.YPos)
                        newY = map.Team1[j].YPos - map.Team1[j].Speed;
                    else if (map.Team1[j].YPos > closest.YPos)
                        newY = map.Team1[j].YPos + map.Team1[j].Speed;
                    else
                        newY = map.Team1[j].YPos;

                    map.UpdatePosition(map.Team1[j], newX, newY);
                }
            }
            
            //Team2 now
            for (int j = 0; j < map.Team2.Count; j++)
            {
                if (!map.Team2[j].CombatStatus)
                {
                    closest = map.Team2[j].ClosestUnit(map.Team1);

                    if (map.Team2[j].XPos < closest.XPos)
                        newX = map.Team2[j].XPos + map.Team2[j].Speed;
                    else if (map.Team2[j].YPos < closest.YPos)
                        newX = map.Team2[j].XPos - map.Team2[j].Speed;
                    else
                        newX = map.Team2[j].XPos;

                    if (map.Team2[j].YPos < closest.YPos)
                        newY = map.Team2[j].YPos + map.Team2[j].Speed;
                    else if (map.Team2[j].YPos < closest.YPos)
                        newY = map.Team2[j].YPos - map.Team2[j].Speed;
                    else
                        newY = map.Team2[j].YPos;

                    map.UpdatePosition(map.Team2[j], newX, newY);
                }
                //Movement if not in combat done
            
            if (map.Team2[j].CombatStatus)
            {
                for (int i = 0; i < map.Team1.Count; i++)
                {
                    //this causes the unit in combat to attack every unit in range, not sure if thats balanced but it works so its fine. (works in game For Honour for quantity balancing so why not)
                    map.Team2[j].Combat(map.Team1[i]);
                }
            }
            //Checking if unit is not in combat now, if in range currently make in combat.
            if (!map.Team2[j].CombatStatus)
            {
                for (int i = 0; i < map.Team1.Count; i++)
                {
                    if (map.Team2[j].AttackRange(map.Team1[i]))
                           map.Team2[j].CombatStatus = true;
                    }
                
            }
            //Checking for health below 25 now, i should maybe add this to only be in combat once someone gets damaged but this works here as well
            if (map.Team2[j].Health < 25)
            {
                    closest = map.Team2[j].ClosestUnit(map.Team1);
                    //If below move directly away from unit closest. This can be advanced to have multiple checks to move in a direction furthest away from units total though that seems excessive.
                    if (map.Team2[j].XPos < closest.XPos)
                        newX = map.Team2[j].XPos - map.Team2[j].Speed;
                    else if (map.Team2[j].XPos > closest.XPos)
                        newX = map.Team2[j].XPos +map.Team2[j].Speed;
                    else
                        newX = map.Team2[j].XPos;

                    if (map.Team2[j].YPos < closest.YPos)
                        newY = map.Team2[j].YPos - map.Team2[j].Speed;
                    else if (map.Team2[j].YPos > closest.YPos)
                        newY = map.Team2[j].YPos + map.Team2[j].Speed;
                    else
                        newY = map.Team2[j].YPos;

                    map.UpdatePosition(map.Team2[j], newX, newY);


                    map.UpdatePosition(map.Team2[j], newX, newY);
                }

        }
        



    }
   }
}
